package model;

public interface Socio {

    public int getQuantidadeDeAcoes();
    public double getValorAcoes();

}
